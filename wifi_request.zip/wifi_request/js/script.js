document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("wifiRequestForm").addEventListener("submit", function(event) {
        event.preventDefault();

        let formData = new FormData(this);

        fetch("submit_request.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            document.getElementById("responseMessage").innerText = data;
            this.reset();
        })
        .catch(error => console.error("Error:", error));
    });
});

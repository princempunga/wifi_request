<?php  
include 'db/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $reg_number = $_POST['reg_number'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone_number'];
    $password_plain = $_POST['password'];  // Get the plain password
    $password_hashed = password_hash($password_plain, PASSWORD_DEFAULT);  // Hash the password

    // Check if Email already exists
    $check_email = $conn->prepare("SELECT id FROM students WHERE email = ?");
    $check_email->bind_param("s", $email);
    $check_email->execute();
    $email_result = $check_email->get_result();

    if ($email_result->num_rows > 0) {
        die("Error: Email already exists. Please use a different email.");
    }

    // Check if Registration Number already exists
    $check_stmt = $conn->prepare("SELECT id FROM students WHERE reg_number = ?");
    $check_stmt->bind_param("s", $reg_number);
    $check_stmt->execute();
    $result = $check_stmt->get_result();

    if ($result->num_rows > 0) {
        // Student exists, retrieve student ID
        $student = $result->fetch_assoc();
        $student_id = $student['id'];

        // Check if student already has a pending Wi-Fi request
        $check_request = $conn->prepare("SELECT * FROM wifi_requests WHERE student_id = ?");
        $check_request->bind_param("i", $student_id);
        $check_request->execute();
        $request_result = $check_request->get_result();

        if ($request_result->num_rows > 0) {
            echo "Error: You have already submitted a Wi-Fi request.";
        } else {
            // Insert Wi-Fi request with password and phone number
            $insert_request = $conn->prepare("INSERT INTO wifi_requests (student_id, email, phone_number, status, password, password_plain) VALUES (?, ?, ?, 'Pending', ?, ?)");
            $insert_request->bind_param("issss", $student_id, $email, $phone_number, $password_hashed, $password_plain);
            if ($insert_request->execute()) {
                echo "Wi-Fi request submitted successfully!";
            } else {
                echo "Error submitting Wi-Fi request: " . $conn->error;
            }
        }
    } else {
        // Student does not exist, register and then insert request
        $stmt = $conn->prepare("INSERT INTO students (full_name, reg_number, email, phone_number) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $full_name, $reg_number, $email, $phone_number);
        if ($stmt->execute()) {
            $student_id = $stmt->insert_id; // Get the newly inserted student ID

            // Insert Wi-Fi request after student is registered
            $insert_request = $conn->prepare("INSERT INTO wifi_requests (student_id, email, phone_number, status, password, password_plain) VALUES (?, ?, ?, 'Pending', ?, ?)");
            $insert_request->bind_param("issss", $student_id, $email, $phone_number, $password_hashed, $password_plain);
            if ($insert_request->execute()) {
                echo "Registration and Wi-Fi request submitted successfully!";
            } else {
                echo "Error submitting Wi-Fi request: " . $conn->error;
            }
        } else {
            echo "Error registering student: " . $conn->error;
        }
    }
}
?>

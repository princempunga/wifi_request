<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Wi-Fi Request</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/script.js"></script>
</head>
<body>
    <div class="request-container">
        <img src="css/img/IUEA-Logo.png" alt="Wi-Fi Request Logo" class="logo">
        <h2>Student Wi-Fi Request</h2>
        <p id="responseMessage" style="color:green;"></p>
        <form id="wifiRequestForm">
            <input type="text" name="full_name" id="full_name" placeholder="Full Name" required>
            <input type="text" name="reg_number" id="reg_number" placeholder="Registration Number" required>
            <input type="email" name="email" id="email" placeholder="Email" required>
            <input type="text" name="phone_number" required placeholder="Enter your phone number">
            <input type="text" name="password" required placeholder="Enter your password">
            <button type="submit">Submit Request</button>
        </form>
    </div>
    <div class="footer">Wi-Fi Request System &copy; 2025</div>
</body>
</html>
